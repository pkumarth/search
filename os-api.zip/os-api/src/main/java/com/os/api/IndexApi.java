package com.os.api;

import com.os.dto.IndexData;
import com.os.service.IndexService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;

@RequestMapping("/api/v1/index")
@RestController
@AllArgsConstructor
public class IndexApi {
    private IndexService indexService;

    @PostMapping("/create/{index}")
    public void createIndex(@PathVariable String index) throws IOException {
        indexService.createIndex(index);
    }

    @DeleteMapping("/delete/{index}")
    public void deleteIndex(@PathVariable String index) throws IOException {
        indexService.deleteIndex(index);
    }

    @PutMapping("/{index}/{id}")
    public void indexDoc(@PathVariable String index, @PathVariable String id, @RequestBody IndexData doc) throws IOException {
        indexService.indexDoc(index, id, doc);
    }


}
