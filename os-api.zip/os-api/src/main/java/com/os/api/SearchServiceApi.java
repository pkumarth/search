package com.os.api;

import com.os.dto.IndexData;
import com.os.service.SearchService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RequestMapping("/api/v1/search")
@RestController
@AllArgsConstructor
public class SearchServiceApi {
    private SearchService searchService;

    @GetMapping("/{index}")
    public List<IndexData> searchDoc(@PathVariable String index) throws IOException {
        return searchService.searchDoc(index);
    }

    @DeleteMapping("/{index}/{id}")
    public void deleteDoc(@PathVariable String index, @PathVariable String id) throws IOException {
        searchService.deleteDoc(index, id);
    }

}
