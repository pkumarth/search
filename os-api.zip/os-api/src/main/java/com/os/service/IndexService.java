package com.os.service;

import com.os.dto.IndexData;

import java.io.IOException;

public interface IndexService {
    void createIndex(String index) throws IOException;

    void deleteIndex(String index) throws IOException;

    void indexDoc(String index, String id, IndexData doc) throws IOException;
}
