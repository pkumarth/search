package com.os.service;

import com.os.dto.IndexData;

import java.io.IOException;
import java.util.List;

public interface SearchService {
    List<IndexData> searchDoc(String index) throws IOException;

    void deleteDoc(String index,String id) throws IOException;
}
