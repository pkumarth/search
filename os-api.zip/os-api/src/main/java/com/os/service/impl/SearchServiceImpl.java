package com.os.service.impl;

import com.os.dto.IndexData;
import com.os.service.SearchService;
import lombok.AllArgsConstructor;
import org.opensearch.client.opensearch.OpenSearchClient;
import org.opensearch.client.opensearch.core.SearchResponse;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
@AllArgsConstructor
public class SearchServiceImpl implements SearchService {
    private OpenSearchClient osClient;
    @Override
    public List<IndexData>  searchDoc(String index) throws IOException {
        SearchResponse<IndexData> searchResponse = osClient.search(s -> s.index(index), IndexData.class);
        List<IndexData> searchDataList= new ArrayList<>();
        for (int i = 0; i< searchResponse.hits().hits().size(); i++) {
            searchDataList.add(searchResponse.hits().hits().get(i).source());
            System.out.println(searchResponse.hits().hits().get(i).source());
        }
        return searchDataList;
    }

    @Override
    public void deleteDoc(String index,String id) throws IOException {
        osClient.delete(b -> b.index(index).id(id));
    }
}
