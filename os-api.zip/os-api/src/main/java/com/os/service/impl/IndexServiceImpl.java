package com.os.service.impl;

import com.os.dto.IndexData;
import com.os.service.IndexService;
import lombok.AllArgsConstructor;
import org.opensearch.client.opensearch.OpenSearchClient;
import org.opensearch.client.opensearch.core.IndexRequest;
import org.opensearch.client.opensearch.indices.*;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
@AllArgsConstructor
public class IndexServiceImpl implements IndexService {
    private OpenSearchClient osClient;

    public void createIndex(String index) throws IOException {
        CreateIndexRequest createIndexRequest = new CreateIndexRequest.Builder().index(index).build();
        osClient.indices().create(createIndexRequest);
        IndexSettings indexSettings = new IndexSettings.Builder().autoExpandReplicas("0-all").build();
        PutIndicesSettingsRequest putIndicesSettingsRequest = new PutIndicesSettingsRequest.Builder().index(index).settings(indexSettings).build();
        osClient.indices().putSettings(putIndicesSettingsRequest);
    }

    public void deleteIndex(String index) throws IOException {
        DeleteIndexRequest deleteIndexRequest = new DeleteIndexRequest.Builder().index(index).build();
        DeleteIndexResponse deleteIndexResponse = osClient.indices().delete(deleteIndexRequest);
    }

    public void indexDoc(String index, String id, IndexData doc) throws IOException {
        IndexRequest<IndexData> indexRequest = new IndexRequest.Builder<IndexData>().index(index).id(id).document(doc).build();
        osClient.index(indexRequest);
    }
}
