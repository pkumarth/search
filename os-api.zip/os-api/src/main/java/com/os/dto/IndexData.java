package com.os.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class IndexData {
    private String DOCID;
    private String app_id;
    private String app_impl_type;
    private Float avg_rating;
    private Float basis_price;
    private String body;
    private String classified_category;
    private Long click_count;
    private String content_id;
    private String content_type;
    private String dictionary_field;
    private Integer dl_count;
    private Integer dl_count_2w;
    private String excl_content_cat_id;
    private String excl_content_cat_name;
    private String excl_shop_cat_id;
    private String excl_shop_cat_name;
    private String ext_keyword;
    private String gen_content_cat_id;
    private String gen_content_cat_name;
    private String gen_shop_cat_id;
    private String gen_shop_cat_name;
    private String hidden_tag;
    private String icon_path;
    private String in_app_purchase;
    private Integer install_count;
    private Integer install_count_2w;
    private Float int_popular_score;
    private String is_free;
    private String is_pre_register;
    private String is_prepost;
    private String is_shown;
    private String is_terms;
    private String main_language;
    private String model_group;
    private String os_id;
    private String popular_score;
    private String promotion_keyword;
    private Integer rating_count;
    private String reg_date;
    private Integer review_count;
    private Integer review_count_2w;
    private Integer sales_amount;
    private Integer sales_amount_2w;
    private String seller_brand;
    private String seller_name;
    private String shop_id;
    private String similar_app_title;
    private String store_type;
    private String support_language;
    private String tag;
    private String tag_eng;
    private String theme_ver;
    private Integer tier_level;
    private String title;
    private String title_auto_srch;
    private String title_eng;
    private String update_date;
}
