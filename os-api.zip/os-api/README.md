# Run opensearch
## pull opensearch image
docker pull opensearchproject/opensearch:2.18.0

## For OpenSearch 2.12 or greater, set a new custom admin password before installation using the following command:
docker run -d -p 9200:9200 -p 9600:9600 -e "discovery.type=single-node" -e "OPENSEARCH_INITIAL_ADMIN_PASSWORD=Ba246d3p@123" opensearchproject/opensearch:2.18.0

## check opensearch is running
curl -ku $OPENSEARCH_ADMIN_USER:$OPENSEARCH_ADMIN_PASSWORD https://localhost:9200

## check container id
docker container ls | grep opensearch

## stop the container
docker stop <containerId>

# Connect Opensearch using Opensearch Java HighlevelRestClient
# copy certificate from opensearch docker container to local file system
docker cp {container}:{HOME}/config/root-ca.pem ./opensearch-root-ca.pem
docker cp 54bf9f50f7c6:/usr/share/opensearch/config/root-ca.pem ./opensearch-root-ca.pem
# Generate custom keyStore/trustStore
keytool -keystore clientkeystore.jks -genkey -keyalg RSA -alias client

# Add opensearch server certificate to trustStrore
keytool -import -keystore clientkeystore.jks -file opensearch-root-ca.pem -alias opensearch


 
